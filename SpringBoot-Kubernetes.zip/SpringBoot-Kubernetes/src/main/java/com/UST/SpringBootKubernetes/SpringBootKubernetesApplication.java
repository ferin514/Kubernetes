package com.UST.SpringBootKubernetes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootKubernetesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKubernetesApplication.class, args);
	}

}
