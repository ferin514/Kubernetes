package com.UST.SpringBootKubernetes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKubernetesApplicationTests {

	@Test
	void contextLoads() {
	}

}
